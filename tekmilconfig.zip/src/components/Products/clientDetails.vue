<template>
    <b-container fluid>
      <h1>Обобщение на офертата:</h1>
      <b-card>
        <div class="card-text">
          {{ chair.title + ' ' + chair.model }}
        </div>
      </b-card>
      <h2>
        Допълнително оборудване
      </h2>
      <b-table :items="options" :fields="tableFields">
          <template slot="title" slot-scope="row">
            <div class="text-left">
              {{ row.item.title + ' ' + row.item.model + ' ' + row.item.manufacturer}}
            </div>
          </template>
      </b-table>
      <b-card header-bg-variant="dark" header-text-variant="white">
        <div class="efok" slot="header">
          <h3>Данни за контакт:</h3>
        </div>
        <p class="text-left">
          За да можем да Ви предложим най-актуална цена за избраното от Вас оборудване, ще ни бъде необходима малко повече инфромация за контакт с Вас.
        </p>
        <div class="card-text">
          <b-form>
            <b-form-group label="Ime" :label-for="customer.firstname">
              <b-form-input v-model="customer.firstname"></b-form-input>
            </b-form-group>
            <b-form-group>
              <label :for="customer.lastname" class="text-left">Фамилия</label>
              <b-form-input v-model="customer.lastname"></b-form-input>
            </b-form-group>
            <b-form-group label="Телефон" :label-for="customer.phone">
              <label :for="customer.phone" class="text-left">Телефон за връзка:</label>
              <b-form-input v-model="customer.phone"></b-form-input>
            </b-form-group>
            <b-row>
              <div style="background-color: red; color: #fff; padding: 10px;" class="text-left">
                Искаме да Ви уведомим, преди да натиснете бутона по-долу, че ние, Фирма Дентакон, няма да споделяме информацията от този формуляр
                с 3-ти лица. Това е обикновена форма за обратна връзка, за да можем да отговорим на Вашето запитване.
              </div>
            </b-row>

            <b-btn>Изпрати запитването</b-btn>
          </b-form>
        </div>
      </b-card>
    </b-container>
</template>

<script>
    export default {
        name: "clientDetails",
      data() {
          return {
            chair: this.$store.state.selectedChair,
            options: this.$store.state.chosenOptions,
            customer: {
              firstname: '',
              lastname: '',
              phone: ''
            },

            tableFields: {
              title: {
                label: 'Наименование'
              },
              qty: {
                label: 'Количество'
              }
            }
          }
      },
      mounted() {
          console.log(this.$store.state.chosenOptions)
        console.log(this.$store.state.selectedChair)
      }

    }
</script>

<style scoped>

</style>
